from distutils.core import setup
setup(name='coconut',
      version='0.0.0',
      description='Coconut',
      author='Ivan E. Cao-Berg',
      author_email='icaoberg@cmu.edu',
      url='http://murphylab.web.cmu.edu/software/',
      py_modules=['coconut'])


