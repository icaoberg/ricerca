COCONUT for Python 0.0
======================

Pre-Requisites
==============
-numpy, scipy

Installation
============
Run
> sudo python setup.py install
 
